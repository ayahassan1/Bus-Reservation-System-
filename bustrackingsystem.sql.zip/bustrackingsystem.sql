-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2019 at 02:09 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bustrackingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `BusPlateNum` varchar(6) NOT NULL,
  `isClassic` tinyint(1) NOT NULL,
  `driver_name` varchar(30) NOT NULL,
  `driver_age` int(11) NOT NULL,
  `driver_nationalID` mediumtext NOT NULL,
  `driver_gender` varchar(6) NOT NULL,
  `driver_position` varchar(30) NOT NULL,
  `driver_email` varchar(50) NOT NULL,
  `driver_username` varchar(30) NOT NULL,
  `driver_password` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`BusPlateNum`, `isClassic`, `driver_name`, `driver_age`, `driver_nationalID`, `driver_gender`, `driver_position`, `driver_email`, `driver_username`, `driver_password`, `status`) VALUES
('10', 0, 'aya', 11, '55555', 'female', 'cairo', 'ayua.com', 'aya55', '98765', 0),
('122', 1, 'Ahmed', 20, '123456789985546', 'male', 'Cairo', 'ayahassan33397@gmail.com', 'hamada', '123456789', 0),
('20', 1, 'aya00', 20, '333333', 'female', 'cairo', 'bustra@yahoo.com', 'aya11', '01100615741 ', 0),
('30', 0, 'ahmed', 15, '5555', 'male', 'cairo', 'aya.com', 'aya1', '55555', 0),
('70', 0, 'aya', 11, '55555', 'female', 'cairo', 'ayua.com', 'aya55', '98765', 0),
('80', 0, 'aya', 11, '55555', 'female', 'cairo', 'ayua.com', 'aya55', '98765', 0),
('90', 1, 'aya', 11, '55555', 'female', 'cairo', 'ayua.com', 'aya55', '98765', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `name` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `NationalID` mediumtext NOT NULL,
  `gender` varchar(20) NOT NULL,
  `position` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(70) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `VISAnum` varchar(20) NOT NULL,
  `VISApassword` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`name`, `age`, `NationalID`, `gender`, `position`, `email`, `username`, `password`, `phone`, `VISAnum`, `VISApassword`) VALUES
('Ahmed', 20, '16516518154516', 'Male', 'Alex', 'ah7694622@gmail.com', 'Ahmed', '292929292', '0156426536', 'ahmed55', '123654789'),
('Aya', 20, '299062584601428', 'Female', 'Cairo', 'ayahassan33397@gmail.com', 'aya333', '25/6/1999', '01100615741', 'aya333', 'aya79'),
('Bassma', 55, '29906251401428', 'Female', 'Cairo', 'bassmahassan744@gmail.com', 'bassma55', '854155456', '011169871', 'bassma', '123456789'),
('Farida', 23, '151257968425888', 'Female', 'Aswan', 'farida_alaaeldin@yahoo.com', 'Farida1', '1256971114', '012108545', 'SDF333', '12369852'),
('Farida', 23, '12345678911545454', 'Female', 'Cairo', 'uniquegirl01996@gmail.com', 'fofo', '123456789', '01100615741', '01100615741', '123456789'),
('Gessica', 32, '584169886455', 'Female', 'Aswan', 'GessyQQ@Yahoo.com', 'Gessy', '585864654', '01255136135', '8888888', '65846846546'),
('Ola', 20, '123456789975655555', 'Female', 'Giza', 'Ola.hazem@gmail.com', 'lolo11', '01100615741', '01100615741', '5555555', '01100615741'),
('Nada', 35, '2997545414401', 'Female', 'Hurghada', 'nadahhesham1@gmail.com', 'nadahesham', '012365410', '012379541', 'nadnod159', 'nadooz'),
('Sally', 30, '2990625199158', 'Female', 'Luxor', 'SallySaad@gmail.com', 'sally1', '98765400', '012378915', 'DBJK55', '12345987'),
('Sama', 45, '294414251401428', 'Female', 'Cairo', 'ayahassan3339@gmail.com', 'samasemo', '55555', '0156456555', 'DERF01', '0011551'),
('Aya', 20, '123456789321654852', 'Female', 'cairo', 'ayahassan3337@gmail.com', 'Yoyo1', '123', '01100615741', '1234567', '01100615741'),
('Zeinab', 21, '299062514645013', 'Female', 'Cairo', 'zeinabahmed2799@gmail.com', 'zeinab1899', '27/1/1999', '010661991', 'zozo23', 'visanum0000');

-- --------------------------------------------------------

--
-- Table structure for table `customers_trips`
--

CREATE TABLE `customers_trips` (
  `username` varchar(30) NOT NULL,
  `Total_Cost_Customer` int(20) NOT NULL,
  `code` varchar(10) NOT NULL,
  `pickup` varchar(50) NOT NULL,
  `pickupDate` varchar(10) NOT NULL,
  `pickupTime` varchar(10) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `arrivalDate` varchar(10) NOT NULL,
  `arrivalTime` varchar(10) NOT NULL,
  `Cost_Seat` int(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `seat_code` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `Code` varchar(10) NOT NULL,
  `pickUp` varchar(30) NOT NULL,
  `pickupDate` varchar(11) NOT NULL,
  `pickupTime` varchar(6) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `arrivalDate` varchar(11) NOT NULL,
  `arrivalTime` varchar(6) NOT NULL,
  `BusPlateNum` varchar(11) NOT NULL,
  `AvailableSeatsNum` int(11) NOT NULL,
  `costPERseat` int(11) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `seat_code` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`Code`, `pickUp`, `pickupDate`, `pickupTime`, `destination`, `arrivalDate`, `arrivalTime`, `BusPlateNum`, `AvailableSeatsNum`, `costPERseat`, `Status`, `seat_code`) VALUES
('T_00', 'Cairo', '5/9/2019', '3:00', 'Cairo', '25/5/2019', '5:00', '90', 24, 120, 'Upcoming', ''),
('T_00+', 'Cairo', '5/9/2019', '3:00', 'Cairo', '25/5/2019', '5:00', '30', 12, 500, 'Upcoming', ''),
('T_1', 'cairo', '25/5/2019', '3:00', 'alex', '25/5/2019', '5:00', '20', 23, 100, 'Upcoming', 'FEKLXRDdj'),
('T_1+', 'cairo', '25/5/2019', '3:00', 'alex', '25/5/2019', '5:00', '10', 12, 120, 'Upcoming', 'FEKLXR'),
('T_12', 'Cairo', '12/05/2019', '08:00', 'Sharm', '12/05/2019', '15:00', '70', 13, 50, 'upcoming', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`BusPlateNum`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`Code`) USING BTREE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
